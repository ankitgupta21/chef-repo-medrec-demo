foglight CHANGELOG
==================

This file is used to list changes made in each version of the foglight cookbook.

0.1.1
-----
- [Vann Orton] - Initial release of foglight

0.1.2
-----

- Vann Orton - added FMS cert import and modifications of the vm.config and the fglam.config.xml

0.1.3
-----

added fglcmd.propertis and fixed the key import

0.1.4
-----

added osAgents receipe and configAgents.sh and fglSetEnv.sh

0.1.5
------

deploy agent packages and create 3 agents

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
