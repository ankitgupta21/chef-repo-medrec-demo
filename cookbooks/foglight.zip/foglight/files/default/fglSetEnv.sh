#!/bin/sh

export JAVA_HOME=/root/Oracle/Middleware/jdk160_21
export PATH=/opt/dsg/bin:$PATH
