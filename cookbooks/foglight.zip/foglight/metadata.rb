name             'foglight'
maintainer       'Dell Software Inc.'
maintainer_email 'vann.orton@software.dell.com'
license          'All rights reserved'
description      'Installs/Configures foglight'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.6'
