#
# Cookbook Name:: foglight
# Recipe:: javaAgents
#
# Copyright 2013, Dell Software Inc.
#
# All rights reserved - Do Not Redistribute
#


cookbook_file "/root/configJavaAgents.sh" do
        source "configJavaAgents.sh"
        mode 0755
end

#execute "launch agents" do
#	command "sh /root/configJavaAgents.sh"
#end


